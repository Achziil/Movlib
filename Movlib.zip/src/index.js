import "regenerator-runtime";
import "../src/style/style.css";
import "./script/component/sidebar.js";
import main from "./script/view/main.js";
main();
